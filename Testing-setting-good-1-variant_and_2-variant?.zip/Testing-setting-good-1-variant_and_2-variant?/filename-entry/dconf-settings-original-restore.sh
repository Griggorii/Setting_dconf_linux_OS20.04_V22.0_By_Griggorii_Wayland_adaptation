dconf load / < dconf-settings-original-restore.ini
