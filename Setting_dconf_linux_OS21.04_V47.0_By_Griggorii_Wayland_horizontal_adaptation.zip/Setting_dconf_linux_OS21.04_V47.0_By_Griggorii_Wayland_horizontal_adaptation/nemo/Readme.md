             Griggorii@gmail.com folder tool manipulation dconf setting 
                                       
                                      Install dconf setting patch light fast
                                       
 1) install nemo 
 
 
$ sudo apt update && sudo apt --reinstall install nemo
 
 
 apple old config
 
$ sudo ./Setting_dconf_linux_OS21.04_V46.0_By_Griggorii_Wayland_vertical_adaptation.sh

New setting patch run dconf-settings-original-restore.sh


run /nemo/tool click dconf-settings-original-restore.sh
