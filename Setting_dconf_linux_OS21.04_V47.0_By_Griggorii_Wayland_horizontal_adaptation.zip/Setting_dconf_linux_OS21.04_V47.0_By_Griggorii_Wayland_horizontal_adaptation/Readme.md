#Only real technologies, not any fictional parasitic distributions support real technology investments and donate VISA 4817 7601 8112 4706
             Griggorii@gmail.com folder tool manipulation dconf setting 
                                       
                                       Install dconf setting
                                       
 1) install nemo full dconf 46.0 
 
 https://github.com/Griggorii/Setting_dconf_linux_OS20.04_V46.0_By_Griggorii_Wayland_adaptation 
 
./Replace_nemo-to-nautilus_dconf_linux_OS21.04_V46.0_By_Griggorii_Wayland_vertical_adaptation.sh backup background image
                                       
Varinat nemo nautilus /tool/dconf-settings-original-restore.sh


dconf load /org/gnome/shell/ < backup-gnome-shell.dconf

dconf load /org/nemo/desktop/ < backup-gnome-desktop.dconf

dconf load /org/gnome/nautilus/ < backup-gnome-nautilus.dconf

dconf load /org/nemo/ < backup-gnome-nemo.dconf

dconf load /org/gnome/gnome-system-monitor/ < backup-gnome-system-monitor.dconf

dconf load /org/gnome/gedit/ < backup-gnome-gedit.dconf

                                             Backup setting
                                             

EOF
dconf dump /org/gnome/shell/ > backup-gnome-shell.dconf
EOF
dconf dump /org/nemo/desktop/ > backup-gnome-desktop.dconf
EOF
dconf dump /org/gnome/nautilus/ > backup-gnome-nautilus.dconf
EOF
dconf dump /org/nemo/ > backup-gnome-nemo.dconf
EOF
dconf dump /org/gnome/gnome-system-monitor/ > backup-gnome-system-monitor.dconf
EOF
dconf dump /org/gnome/gedit/ > backup-gnome-gedit.dconf
EOF




