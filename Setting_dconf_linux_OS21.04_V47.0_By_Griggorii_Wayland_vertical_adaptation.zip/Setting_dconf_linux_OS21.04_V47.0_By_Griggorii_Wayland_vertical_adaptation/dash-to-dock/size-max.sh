dconf load / < size-max.dconf
