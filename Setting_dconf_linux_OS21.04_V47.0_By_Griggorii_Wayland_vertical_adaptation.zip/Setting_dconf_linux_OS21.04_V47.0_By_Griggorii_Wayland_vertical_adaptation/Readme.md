#Only real technologies, not any fictional parasitic distributions support real technology investments and donate VISA 4817 7601 8112 4706
             Griggorii@gmail.com folder tool manipulation dconf setting 
                                       
                                       Install dconf setting
                                       
 1) Apple Replace_nemo-to-nautilus_dconf_linux_OS21.04_V46.0_By_Griggorii_Wayland_vertical_adaptation.sh backup background image
                                       
dconf load /org/nemo/desktop/ < backup-gnome-desktop.dconf && dconf load /org/gnome/nautilus/ < backup-gnome-nautilus.dconf && dconf load /org/nemo/ < backup-gnome-nemo.dconf && dconf load /org/gnome/shell/ < backup-gnome-shell.dconf  && dconf load /org/gnome/gnome-system-monitor/ < backup-gnome-system-monitor.dconf

dconf load /org/gnome/shell/ < backup-gnome-shell.dconf

dconf load /org/nemo/desktop/ < backup-gnome-desktop.dconf

dconf load /org/gnome/nautilus/ < backup-gnome-nautilus.dconf

dconf load /org/nemo/ < backup-gnome-nemo.dconf

dconf load /org/gnome/gnome-system-monitor/ < backup-gnome-system-monitor.dconf


                                             Backup setting
                                             

EOF
dconf dump /org/gnome/shell/ > backup-gnome-shell.dconf
EOF
dconf dump /org/nemo/desktop/ > backup-gnome-desktop.dconf
EOF
dconf dump /org/gnome/nautilus/ > backup-gnome-nautilus.dconf
EOF
dconf dump /org/nemo/ > backup-gnome-nemo.dconf
EOF
dconf dump /org/gnome/gnome-system-monitor/ > backup-gnome-system-monitor.dconf
EOF




