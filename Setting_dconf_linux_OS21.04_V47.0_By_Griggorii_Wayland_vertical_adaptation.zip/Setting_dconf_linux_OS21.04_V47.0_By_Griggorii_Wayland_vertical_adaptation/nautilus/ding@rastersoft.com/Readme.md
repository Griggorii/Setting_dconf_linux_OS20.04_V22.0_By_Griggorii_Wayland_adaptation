                                      Griggorii@gmail.com
                                             
                                       desktop icons extent
                                              
     shell-version 3.38 (not support beta ubuntu 21.04 gnome 40) support ubuntu lts stable 3.38-40.1.0
                                              
sudo cp -r ding@rastersoft.com /usr/share/gnome-shell/extensions/

                   terminal folder <tool> command and run click mouse

dconf-settings-original-restore.sh


                                              Uninstall 
                                              
sudo rm -rf /usr/share/gnome-shell/extensions/ding@rastersoft.com
