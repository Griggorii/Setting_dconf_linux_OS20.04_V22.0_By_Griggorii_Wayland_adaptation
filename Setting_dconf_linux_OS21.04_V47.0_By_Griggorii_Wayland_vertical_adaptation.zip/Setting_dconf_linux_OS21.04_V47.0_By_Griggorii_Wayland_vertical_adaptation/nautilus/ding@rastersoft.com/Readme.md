                                      Griggorii@gmail.com
                                             
                                       desktop icons extent
                                              
     shell-version 3.38 (not support beta ubuntu 21.04 gnome 40) support ubuntu lts stable 3.38-40.1.0
                                              
sudo cp -r ding@rastersoft.com /usr/share/gnome-shell/extensions/

                   terminal folder <tool> command

dconf load /org/nemo/desktop/ < backup-gnome-desktop.dconf && dconf load /org/gnome/nautilus/ < backup-gnome-nautilus.dconf && dconf load /org/nemo/ < backup-gnome-nemo.dconf && dconf load /org/gnome/shell/ < backup-gnome-shell.dconf
