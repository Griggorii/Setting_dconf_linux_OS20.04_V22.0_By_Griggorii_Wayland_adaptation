dconf load / < dash-to-dock-off-global-theme-color-app.dconf
