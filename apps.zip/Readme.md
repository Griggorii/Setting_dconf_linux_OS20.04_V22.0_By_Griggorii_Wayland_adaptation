Griggorii autogenerations xml scheme my experiments desktop patent license - > griggorii@gmail.com home/<user>/.gnome/
