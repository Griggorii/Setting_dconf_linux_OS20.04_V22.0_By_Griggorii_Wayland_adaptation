Griggorii autogenerations xml scheme dbus my experiments desktop patent license - > griggorii@gmail.com home/<user>/.gconf and home/<user>/.gnome/
