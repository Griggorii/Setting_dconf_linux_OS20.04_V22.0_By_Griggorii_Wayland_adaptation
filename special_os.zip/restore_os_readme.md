                                    Griggorii@gmail.com stable os ubuntu 20.04 glib-2.31

sudo apt update && sudo dpkg --set-selections < special_os_wayland_pack.txt
